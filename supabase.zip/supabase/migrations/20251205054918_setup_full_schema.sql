-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- SECTION 2 HELPERS: Team Tables
CREATE TABLE public.teams (
    team_id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    name text NOT NULL
);

CREATE TABLE public.user_teams (
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
    team_id uuid REFERENCES public.teams(team_id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, team_id)
);

-- SECTION 1: CORE TABLES
-- 1. Leads Table [cite: 5, 9]
CREATE TABLE public.leads (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id uuid NOT NULL,
    owner_id uuid REFERENCES auth.users(id),
    stage text NOT NULL,
    title text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- 2. Applications Table [cite: 6, 10]
CREATE TABLE public.applications (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id uuid NOT NULL,
    lead_id uuid NOT NULL REFERENCES public.leads(id) ON DELETE CASCADE,
    status text NOT NULL,
    title text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- 3. Tasks Table [cite: 7, 11]
CREATE TABLE public.tasks (
    id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
    tenant_id uuid NOT NULL,
    related_id uuid NOT NULL REFERENCES public.applications(id) ON DELETE CASCADE,
    title text NOT NULL,
    type text NOT NULL,
    status text NOT NULL DEFAULT 'pending',
    due_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    
    -- Constraints [cite: 18, 21]
    CONSTRAINT task_type_check CHECK (type IN ('call', 'email', 'review')),
    CONSTRAINT task_due_date_check CHECK (due_at >= created_at)
);

-- INDEXING [cite: 13-16]
CREATE INDEX idx_leads_owner_stage ON public.leads (owner_id, stage, created_at);
CREATE INDEX idx_apps_lead ON public.applications (lead_id);
CREATE INDEX idx_tasks_due ON public.tasks (due_at);

-- SECTION 2: RLS POLICIES
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

-- Policy: Counselors read own/team leads, Admins read all [cite: 28-31]
CREATE POLICY "Access Control" ON public.leads FOR SELECT USING (
  (auth.jwt() ->> 'role' = 'admin') OR
  (owner_id = auth.uid()) OR
  (EXISTS (
    SELECT 1 FROM public.user_teams ut_lead 
    JOIN public.user_teams ut_user ON ut_lead.team_id = ut_user.team_id 
    WHERE ut_lead.user_id = leads.owner_id AND ut_user.user_id = auth.uid()
  ))
);

-- Policy: Insert [cite: 39]
CREATE POLICY "Insert Control" ON public.leads FOR INSERT WITH CHECK (
  (auth.jwt() ->> 'role' = 'admin') OR (owner_id = auth.uid())
);