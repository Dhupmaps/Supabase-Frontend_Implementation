// [cite: 41, 61]
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.42.5'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    // 1. Setup Client [cite: 64]
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // 2. Parse Input [cite: 42]
    const { application_id, task_type, due_at } = await req.json()

    // 3. Validate [cite: 50, 53]
    if (!['call', 'email', 'review'].includes(task_type)) {
        throw new Error('Invalid task_type')
    }
    if (new Date(due_at) <= new Date()) {
        throw new Error('due_at must be in future')
    }

    // 4. Insert Task [cite: 54]
    const { data, error } = await supabase
      .from('tasks')
      .insert({
        related_id: application_id,
        type: task_type,
        due_at: due_at,
        title: 'New Task',
        tenant_id: '00000000-0000-0000-0000-000000000000' // dummy uuid for local test
      })
      .select()
      .single()

    if (error) throw error

    // 5. Broadcast Event [cite: 55]
    await supabase.realtime.channel('tasks').send({
        type: 'broadcast',
        event: 'task.created',
        payload: { id: data.id }
    })

    return new Response(JSON.stringify({ success: true, task_id: data.id }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200
    })

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 400
    })
  }
})