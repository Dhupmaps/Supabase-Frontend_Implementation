'use client';

import { createClient } from '@supabase/supabase-js';
import { QueryClient, QueryClientProvider, useQuery, useMutation } from '@tanstack/react-query';
import { format } from 'date-fns'; // Optional: for nice date formatting if installed, otherwise we use native Date

// 1. Setup Supabase Client
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

const queryClient = new QueryClient();

// --- Components ---

function Navbar() {
  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-5xl mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold">L</div>
          <span className="text-xl font-bold text-gray-900">LearnLynk</span>
        </div>
        <div className="flex items-center gap-4">
          <div className="h-8 w-8 rounded-full bg-gray-200 border-2 border-white shadow-sm overflow-hidden">
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="User" />
          </div>
        </div>
      </div>
    </nav>
  );
}

function StatCard({ title, value, color }: { title: string, value: string, color: string }) {
  return (
    <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col">
      <span className="text-gray-500 text-sm font-medium uppercase tracking-wider">{title}</span>
      <span className={`text-3xl font-extrabold mt-2 ${color}`}>{value}</span>
    </div>
  );
}

function Dashboard() {
  // Fetch Tasks
  const { data: tasks, isLoading, error } = useQuery({
    queryKey: ['tasks'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('status', 'pending')
        .order('due_at', { ascending: true });
      if (error) throw error;
      return data;
    }
  });

  // Mutation to Complete Task
  const mutation = useMutation({
    mutationFn: async (id: string) => {
      await supabase.from('tasks').update({ status: 'complete' }).eq('id', id);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tasks'] })
  });

  if (isLoading) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center text-red-500">
      Failed to load tasks. Please check your connection.
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans pb-20">
      <Navbar />

      <main className="max-w-5xl mx-auto px-6 pt-10">
        
        {/* Header Section */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-gray-900">Good Morning, Counselor!</h1>
          <p className="text-gray-500 mt-2">Here is your agenda for today.</p>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          <StatCard title="Tasks Due" value={tasks?.length || 0} color="text-indigo-600" />
          <StatCard title="Urgent" value="0" color="text-red-500" />
          <StatCard title="Completed" value="12" color="text-green-600" />
        </div>

        {/* Tasks Table Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-6 py-5 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
            <h3 className="font-semibold text-gray-800 text-lg">Today's Tasks</h3>
            <span className="text-xs font-medium bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full">
              {tasks?.length} Pending
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Task Title</th>
                  <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Type</th>
                  <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Due At</th>
                  <th className="px-6 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wider text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {tasks?.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-10 text-center text-gray-400">
                      <p className="text-sm">No tasks due today. All caught up!</p>
                    </td>
                  </tr>
                ) : (
                  tasks?.map((task: any) => (
                    <tr key={task.id} className="group hover:bg-indigo-50/30 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-2 h-2 rounded-full ${new Date(task.due_at) < new Date() ? 'bg-red-500' : 'bg-green-500'}`}></div>
                          <span className="font-medium text-gray-700 group-hover:text-indigo-700 transition-colors">{task.title}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 capitalize">
                          {task.type}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        {new Date(task.due_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => mutation.mutate(task.id)}
                          className="text-sm bg-white border border-gray-300 hover:border-indigo-500 hover:text-indigo-600 text-gray-600 font-medium py-1.5 px-4 rounded-lg shadow-sm transition-all active:scale-95"
                        >
                          Mark Complete
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}

export default function Page() {
  return (
    <QueryClientProvider client={queryClient}>
      <Dashboard />
    </QueryClientProvider>
  );
}